SonarQube CIS Plugin
==========

Prerequisites
-------------

* [NodeJS](https://nodejs.org/en/)

Scripts
-------

* run "npm install" to setup your env
