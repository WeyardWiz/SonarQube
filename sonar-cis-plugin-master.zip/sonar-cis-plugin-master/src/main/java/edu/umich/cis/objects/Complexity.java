package edu.umich.cis.objects;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class Complexity {

    private Integer complexity;
    private LocalDateTime localDateTime;
}
