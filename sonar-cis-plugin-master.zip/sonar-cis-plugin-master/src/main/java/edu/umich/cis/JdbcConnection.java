package edu.umich.cis;

public class JdbcConnection {
    public static String url = "jdbc:mysql://localhost:3306/sonarqube";
    public static String user = "root";
    public static String password = "";

}
